create table HIBERNATE_SEQUENCES (
    SEQUENCE_NAME varchar(255),
    SEQUENCE_NEXT_HI_VALUE integer
);
