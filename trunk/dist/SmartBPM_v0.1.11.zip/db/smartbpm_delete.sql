delete from user_acc;

delete from state;

delete from process_type;

delete from process_type_node;

delete from attribute_type;

delete from process;

delete from node;

delete from node_attribute_type;
