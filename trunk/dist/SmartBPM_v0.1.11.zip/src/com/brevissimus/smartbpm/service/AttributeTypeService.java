package com.brevissimus.smartbpm.service;

import com.brevissimus.smartbpm.common.BaseService;


/**
 *<p>StateService</p>
 *<p>Created by <a href="mailto:csaba.tenkes@brevissimus.eu">Csaba Tenkes</a>
 *<br/>Date: 2009.05.11.</p>
 */

public class AttributeTypeService extends BaseService {

}

