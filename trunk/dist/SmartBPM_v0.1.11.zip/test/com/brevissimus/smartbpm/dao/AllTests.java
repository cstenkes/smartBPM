package com.brevissimus.smartbpm.dao;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
//AttributeDAOTest.class,
AttributeTypeDAOTest.class
//,NodeDAOTest.class,
//ProcessDAOTest.class,ProcessTypeDAOTest.class,StateDAOTest.class,UserDAOTest.class
})
public class AllTests {
}

