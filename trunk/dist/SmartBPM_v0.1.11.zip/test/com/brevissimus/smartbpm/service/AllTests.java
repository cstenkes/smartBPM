package com.brevissimus.smartbpm.service;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
//AttributeServiceTest.class,
//AttributeTypeServiceTest.class,
//NodeServiceTest.class,
ProcessServiceTest.class
//ProcessTypeServiceTest.class,
//StateServiceTest.class,
//UserServiceTest.class
})
public class AllTests {
}

