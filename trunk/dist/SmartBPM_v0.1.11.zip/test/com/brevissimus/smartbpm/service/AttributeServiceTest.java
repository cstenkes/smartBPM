package com.brevissimus.smartbpm.service;

import junit.framework.TestCase;

import org.apache.log4j.Logger;

/**
 *<p>StateService</p>
 *<p>Created by <a href="mailto:csaba.tenkes@brevissimus.eu">Csaba Tenkes</a>
 *<br/>Date: 2009.05.11.</p>
 */

public class AttributeServiceTest extends TestCase {
    private static final Logger logger = Logger.getLogger(AttributeServiceTest.class);

 
}

